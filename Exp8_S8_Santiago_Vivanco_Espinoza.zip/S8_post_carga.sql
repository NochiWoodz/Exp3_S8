-- ===============================================================
-- PRY2205 - Semana 8 (post-carga)
-- Ejecutar conectado como: PRY2205_S8
-- Objetivo: construir tabla de control de stock por libro (CTAS),
--           secuencia + trigger para correlativo,
--           vista de detalle de multas con rebaja por carrera,
--           e índices sugeridos.
-- ===============================================================

SET SERVEROUTPUT ON
SET FEEDBACK ON
SET LINESIZE 220
SET PAGESIZE 200
ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD';

PROMPT ==== Limpieza segura ====
BEGIN EXECUTE IMMEDIATE 'DROP TRIGGER TRG_CONTROL_STOCK_PK'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE SEQ_CONTROL_STOCK'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE CONTROL_STOCK_LIBROS PURGE'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP VIEW VW_DETALLE_MULTAS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP INDEX IDX_PRES_FECHA_TERMINO'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP INDEX IDX_EJEMPLAR_LIBRO'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP INDEX IDX_ALUMNO_CARRERA'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP INDEX IDX_PRESTAMO_EMPLEADO'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
PROMPT Limpieza OK

PROMPT ==== 1) Secuencia para correlativo ====
CREATE SEQUENCE SEQ_CONTROL_STOCK START WITH 1 INCREMENT BY 1 NOCACHE;

PROMPT ==== 2) CTAS CONTROL_STOCK_LIBROS ====
-- Mes objetivo = mes actual - 24 meses
CREATE TABLE CONTROL_STOCK_LIBROS AS
SELECT
  CAST(NULL AS NUMBER) AS nro,
  l.libroid,
  INITCAP(l.nombre_libro)       AS nombre_libro,
  COUNT(DISTINCT e.ejemplarid)  AS total_ejemplares,
  SUM(CASE WHEN EXISTS (
            SELECT 1
            FROM PRESTAMO p2
            WHERE p2.libroid = e.libroid
              AND p2.ejemplarid = e.ejemplarid
              AND p2.fecha_inicio BETWEEN TRUNC(ADD_MONTHS(SYSDATE,-24),'MM')
                                      AND LAST_DAY(TRUNC(ADD_MONTHS(SYSDATE,-24),'MM'))
              AND p2.empleadoid IN (190,180,150)
          ) THEN 1 ELSE 0 END)  AS en_prestamo_mes,
  COUNT(DISTINCT e.ejemplarid) 
    - SUM(CASE WHEN EXISTS (
            SELECT 1 FROM PRESTAMO p2
             WHERE p2.libroid = e.libroid
               AND p2.ejemplarid = e.ejemplarid
               AND p2.fecha_inicio BETWEEN TRUNC(ADD_MONTHS(SYSDATE,-24),'MM')
                                       AND LAST_DAY(TRUNC(ADD_MONTHS(SYSDATE,-24),'MM'))
               AND p2.empleadoid IN (190,180,150)
          ) THEN 1 ELSE 0 END)  AS disponibles_mes,
  ROUND(
    100 * ( 
      SUM(CASE WHEN EXISTS (
              SELECT 1 FROM PRESTAMO p2
               WHERE p2.libroid = e.libroid
                 AND p2.ejemplarid = e.ejemplarid
                 AND p2.fecha_inicio BETWEEN TRUNC(ADD_MONTHS(SYSDATE,-24),'MM')
                                         AND LAST_DAY(TRUNC(ADD_MONTHS(SYSDATE,-24),'MM'))
                 AND p2.empleadoid IN (190,180,150)
            ) THEN 1 ELSE 0 END)
      / NULLIF(COUNT(DISTINCT e.ejemplarid),0)
    )
  ) AS porc_prestamo_mes
FROM LIBRO l
JOIN EJEMPLAR e ON e.libroid = l.libroid
GROUP BY l.libroid, l.nombre_libro
ORDER BY l.libroid;

PROMPT ==== 3) Trigger correlativo ====
CREATE OR REPLACE TRIGGER TRG_CONTROL_STOCK_PK
BEFORE INSERT ON CONTROL_STOCK_LIBROS
FOR EACH ROW
BEGIN
  IF :NEW.nro IS NULL THEN
    :NEW.nro := SEQ_CONTROL_STOCK.NEXTVAL;
  END IF;
END;
/

PROMPT ==== 4) Vista de detalle de multas con rebaja por carrera ====
/*
  Reglas implementadas:
    - días de atraso = GREATEST(0, TRUNC(fecha_entrega) - TRUNC(fecha_termino))
    - valor multa por día según rango VALOR_MULTA_PRESTAMO (cant_dias_ini/ter)
      -> se usa el rango al que pertenece el total de días de atraso
    - rebaja por carrera (REBAJA_MULTA.porc_rebaja_multa)
    - sólo préstamos del año (SYSDATE - 24 meses)
    - orden por fecha_entrega DESC
*/
CREATE OR REPLACE VIEW VW_DETALLE_MULTAS AS
SELECT
  p.prestamoid,
  a.alumnoid,
  INITCAP(a.apaterno||' '||a.amaterno||', '||a.nombre) AS alumno,
  c.descripcion AS carrera,
  l.libroid,
  l.nombre_libro,
  l.precio,
  p.fecha_termino,
  p.fecha_entrega,
  GREATEST(0, TRUNC(p.fecha_entrega) - TRUNC(p.fecha_termino)) AS dias_atraso,
  -- tarifa por día según rango
  vmp.valor_multa                                                AS valor_multa_dia,
  -- multa base (sin rebaja)
  GREATEST(0, TRUNC(p.fecha_entrega) - TRUNC(p.fecha_termino)) * vmp.valor_multa AS multa_base,
  -- porcentaje de rebaja (0 si no tiene)
  NVL(rm.porc_rebaja_multa,0)                                    AS porc_rebaja,
  -- multa con rebaja
  ROUND( (GREATEST(0, TRUNC(p.fecha_entrega) - TRUNC(p.fecha_termino)) * vmp.valor_multa)
         * (1 - NVL(rm.porc_rebaja_multa,0)/100) )               AS multa_final
FROM PRESTAMO p
JOIN ALUMNO   a ON a.alumnoid = p.alumnoid
JOIN CARRERA  c ON c.carreraid = a.carreraid
JOIN EJEMPLAR e ON e.libroid = p.libroid AND e.ejemplarid = p.ejemplarid
JOIN LIBRO    l ON l.libroid  = e.libroid
-- Busca el valor de multa correspondiente al total de días en atraso
LEFT JOIN VALOR_MULTA_PRESTAMO vmp
       ON GREATEST(0, TRUNC(p.fecha_entrega) - TRUNC(p.fecha_termino))
          BETWEEN vmp.cant_dias_ini AND vmp.cant_dias_ter
-- Rebaja de multa por carrera (si aplica)
LEFT JOIN REBAJA_MULTA rm ON rm.carreraid = c.carreraid
WHERE EXTRACT(YEAR FROM p.fecha_termino) = EXTRACT(YEAR FROM ADD_MONTHS(SYSDATE,-24))
  AND p.fecha_entrega > p.fecha_termino
ORDER BY p.fecha_entrega DESC;

PROMPT ==== 5) Índices sugeridos ====
-- Filtros y joins más usados en la vista/consultas
CREATE INDEX IDX_PRES_FECHA_TERMINO ON PRESTAMO(TRUNC(fecha_termino));
CREATE INDEX IDX_PRESTAMO_EMPLEADO  ON PRESTAMO(empleadoid);
CREATE INDEX IDX_EJEMPLAR_LIBRO     ON EJEMPLAR(libroid);
CREATE INDEX IDX_ALUMNO_CARRERA     ON ALUMNO(carreraid);

PROMPT ==== 6) Muestras para revisión rápida ====
COLUMN nombre_libro FORMAT A40
SELECT * FROM CONTROL_STOCK_LIBROS ORDER BY libroid FETCH FIRST 10 ROWS ONLY;

SELECT prestamoid, alumno, carrera, nombre_libro, dias_atraso, valor_multa_dia, multa_final
FROM VW_DETALLE_MULTAS
FETCH FIRST 10 ROWS ONLY;

PROMPT ==== Fin post-carga S8 ====
